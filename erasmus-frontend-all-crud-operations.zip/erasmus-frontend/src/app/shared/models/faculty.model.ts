export interface FacultyModel {
   facultyCode?: string; //id-ul meu tip UUID
   name: string;
   universityCode: string;
   description: string;
   compositeKey: string;
}
