import { Component } from '@angular/core';

@Component({
  selector: 'app-faculty-card',
  templateUrl: './faculty-card.component.html',
  styleUrl: './faculty-card.component.css'
})
export class FacultyCardComponent {

}
