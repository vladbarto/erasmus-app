export interface FacultyModel {
   name: string;
   universityCode: string;
   description: string;
   compositeKey: string;
}
