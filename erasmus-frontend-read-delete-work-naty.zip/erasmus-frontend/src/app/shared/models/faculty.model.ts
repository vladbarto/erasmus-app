export interface FacultyModel {
   facultyCode: string;
   name: string;
   universityCode: string;
   description: string;
   compositeKey: string;
}
